package main
import "fmt"
func main(){
var x = 10
y := 5
fmt.Println(x + y)
}
