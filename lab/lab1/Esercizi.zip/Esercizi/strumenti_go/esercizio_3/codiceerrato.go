package main

import fmt

func main {

var x = 10
var y = 15

sum = x + y

fmt.Println("La somma è ", sum

}
}


